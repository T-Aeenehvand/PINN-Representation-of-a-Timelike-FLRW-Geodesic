# Paper 1 — Controlled 2×2 Ablation + Affine Fairness Control

Run ID: 20260925T230536Z_c8ce5c
Seed: 42
Profile: paper

## Controlled factors

Primary factorial: representation (affine second-order vs conformal first-integral) × sampling (fixed vs RAR).
Fairness control: affine second-order equations written in dimensionless affine/output variables using scales derived only from prescribed initial data.

## Measured errors

| Representation | RAR | eta(lambda) rel L2 | x(lambda) rel L2 | max p residual | max kappa residual |
|---|---:|---:|---:|---:|---:|
| affine_second_order | False | 9.450413e-02 | 2.121800e-01 | 1.677444e+00 | 4.093209e+00 |
| affine_second_order | True | 1.525118e-01 | 4.419624e-01 | 1.163942e+00 | 3.877482e+00 |
| conformal_first_integral | False | 8.811673e-05 | 1.704354e-04 | 7.815028e-03 | 2.316106e-02 |
| conformal_first_integral | True | 1.257410e-04 | 2.160519e-04 | 7.927516e-03 | 1.737090e-02 |
| affine_preconditioned | False | 9.671038e+00 | 4.420038e+00 | 7.894186e+06 | 1.290576e+09 |
| affine_preconditioned | True | 7.280358e-02 | 7.356452e-02 | 9.709121e-01 | 7.662353e-01 |

## Reference consistency

Raw-vs-reduced reference max |eta| discrepancy: 0.000000e+00
Raw-vs-reduced reference max |x| discrepancy: 9.582001e-10
Raw-vs-reduced reference max |lambda| discrepancy: 1.983606e-09

## Interpretation discipline

The fairness control tests whether straightforward affine-specific nondimensionalization materially closes the performance gap. A remaining large conformal advantage strengthens the representation-level interpretation, but it is not a proof of universal superiority outside the tested benchmark and architecture family.